[
  {
    "_id": ObjectId("67b9dc335ed185130c1925e9"),
    "centerID": "UTYC-636",
    "password": "$2b$10$SLELgGTNYBhPfaXv1kW9D.hdln8mbtJoviBsHFW3UltGoxOA45e0m",
    "lat": 11.55231,
    "lng": 77.05398,
    "centerName": "South Zone District 7",
    "__v": 0
  },
  {
    "_id": ObjectId("67b9dc335ed185130c1925ea"),
    "centerID": "ARGM-282",
    "password": "$2b$10$SLELgGTNYBhPfaXv1kW9D.hdln8mbtJoviBsHFW3UltGoxOA45e0m",
    "lat": 24.637084,
    "lng": 78.830328,
    "centerName": "Central Zone District 5",
    "__v": 0
  },
  {
    "_id": ObjectId("67b9dc335ed185130c1925eb"),
    "centerID": "JCRE-411",
    "password": "$2b$10$SLELgGTNYBhPfaXv1kW9D.hdln8mbtJoviBsHFW3UltGoxOA45e0m",
    "lat": 19.513574,
    "lng": 73.452482,
    "centerName": "West Zone District 1",
    "__v": 0
  },
  {
    "_id": ObjectId("67b9dc335ed185130c1925ec"),
    "centerID": "UOPT-735",
    "password": "$2b$10$SLELgGTNYBhPfaXv1kW9D.hdln8mbtJoviBsHFW3UltGoxOA45e0m",
    "lat": 30.2672,
    "lng": 76.934269,
    "centerName": "North Zone District 1",
    "__v": 0
  },
  {
    "_id": ObjectId("67b9dc335ed185130c1925ed"),
    "centerID": "KXGW-472",
    "password": "$2b$10$SLELgGTNYBhPfaXv1kW9D.hdln8mbtJoviBsHFW3UltGoxOA45e0m",
    "lat": 23.505097,
    "lng": 88.275046,
    "centerName": "East Zone District 1",
    "__v": 0
  },
  {
    "_id": ObjectId("67b9dc335ed185130c1925ee"),
    "centerID": "APTN-953",
    "password": "$2b$10$SLELgGTNYBhPfaXv1kW9D.hdln8mbtJoviBsHFW3UltGoxOA45e0m",
    "lat": 23.686912,
    "lng": 77.887807,
    "centerName": "Central Zone District 4",
    "__v": 0
  },
  {
    "_id": ObjectId("67b9dc335ed185130c1925ef"),
    "centerID": "RNQW-468",
    "password": "$2b$10$SLELgGTNYBhPfaXv1kW9D.hdln8mbtJoviBsHFW3UltGoxOA45e0m",
    "lat": 23.417124,
    "lng": 88.059155,
    "centerName": "East Zone District 1",
    "__v": 0
  },
  {
    "_id": ObjectId("67b9dc335ed185130c1925f0"),
    "centerID": "BTXK-830",
    "password": "$2b$10$SLELgGTNYBhPfaXv1kW9D.hdln8mbtJoviBsHFW3UltGoxOA45e0m",
    "lat": 12.848645,
    "lng": 78.937694,
    "centerName": "South Zone District 2",
    "__v": 0
  },
  {
    "_id": ObjectId("67b9dc335ed185130c1925f1"),
    "centerID": "GZJD-696",
    "password": "$2b$10$SLELgGTNYBhPfaXv1kW9D.hdln8mbtJoviBsHFW3UltGoxOA45e0m",
    "lat": 22.163249,
    "lng": 88.480121,
    "centerName": "East Zone District 1",
    "__v": 0
  },
  {
    "_id": ObjectId("67b9dc335ed185130c1925f2"),
    "centerID": "HBGY-224",
    "password": "$2b$10$SLELgGTNYBhPfaXv1kW9D.hdln8mbtJoviBsHFW3UltGoxOA45e0m",
    "lat": 20.339216,
    "lng": 72.756435,
    "centerName": "West Zone District 6",
    "__v": 0
  }
]
